from django.apps import AppConfig


class ContactusConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "contactus"
    verbose_name = 'تماس با ما'
