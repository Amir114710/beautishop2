from django.contrib import admin
from .models import *

admin.site.register(Poster)
admin.site.register(Brand)
admin.site.register(LittlePoster)
admin.site.register(ShopAttr)
admin.site.register(SocialMedia)
admin.site.register(Questions)
admin.site.register(CustomerClub)
admin.site.register(Video)
admin.site.register(Banner)
admin.site.register(Law)